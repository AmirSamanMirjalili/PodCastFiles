total time: 35min
# History and Motivation  (10min)
## history
 
موضوعی که می خوام در موردش  صحبت کنم مربوط به ارتباط بین اختلال حس بویایی با  با بیماری های مرتبط با اختلالات حرکتیه 

، تو این پادکست ما به طور خاص این اختلال حس بویایی رو برای بیماری پارکینسون تشریح میکنیم 

پادکست حاضر از ۵ بخش تشکیل شده � ابتدا در بخش اول در رابطه با تاریخچه و انگیزه ای که پشت کشف این ارتباط بوده صحبت می‌کنیم در بخش دوم در رابطه با روش های کلینیکی که برای ارزیابی حس بویایی در تحقیقات پیشرو استفاده شدن صحبت می‌کنیم در بخش سوم در رابطه با اینکه چرا حس بویایی میتونه به عنوان یک بیومارکر یا به عبارت دیگه یک ردپای بیولوژیکی از بیماری‌ پارکینسون باشه 

در بخش چهارم دور مورد منشا ارتباط بین اختلال حس بویایی و بیماری پارکینسون صحبت میکنیم و در قسمت پنجم هم به صورت کوتاه در مورد مباحثی که هنوز در این پدیده مبهم موندن و به عنوان future work میشه بهشون نگاه کرد صحبت کنیم

**
خوب در این بخش میخوایم  در مورد تارخچه و انگیزه ای که بین کشف ارتباط اختلال حس بویایی با بیماری پارکینسون هست صحبت کنیم

۱-بیماری پارکینسون به عنوان یکی از بیماری‌های رایج از دست بیماری های مخرب شبکه عصبی یا  [[neurodegenerative]] 

هست ،این بیماری در حال حاضر در سراسر دنیا حدود ۱۰ میلییون مبتلا داره و پیش بین میشه تا ۲۰۳۰ این آمار دو برابر بشه ، روش های کلینیکی برای تشخیص این بیماری در حال حاضر motor base
یا مربوط به حرکت هستن . از این روش ها میشه به سنجش
tremor (لرزش بدن)، breadykansia ( مربوط به آهستگی یا فریز شدن حرکت)، rigidity (مربوط به میزان سفتی ماهیچه ها) و postral_instability (تلاش برای حفظ تعادله)،
تحقیقات نشون داده که علائم بیماری پارکینسون فراتر از علایم حرکتیه و علایم غیر حرکتی زیادی می تونه این علایم حرکتی رو سال ها زودتر پیش بینی کنه، یکی از این علایم اختلال حس بویاییه  [[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease#^cc3736]]

ارتباط بین اختلال حس بویایی و بیماری پارکینسون اولین بار توسط آقایان انصاری و جانسون در سال ۱۹۷۵ گزارش شد اما روشی که برای این ارزیابی استفاده کرده بودن استاندارد نبود چون در آن زمان روش استانداردی برای ارزیابی حس بویایی وجود نداشت
[[Olfactory Dysfunction in Familial and Sporadic Parkinson’s Disease#^fb47df]]

تا اینکه تا سال ۱۹۸۰ دانشگاه پنسیلوانیا روشی رو با نام اختصار
(َUPSIT) ارائه داد 
و بعد از اون صد ها مقاله در رابطه با ارتباط بین حس بویایی و بیماری پارکینسون منتشر شد
[[Olfaction in Parkinson's disease and related disorders#^a280fc]]
، در بین این مقالات مقاله ای که به صورت معتبر و با استناد بالا ارتباط بین حس بویایی و بیمار
پارکینسون رو گزارش داد مقاله آقای راس و همکارانشون بود که حدود ۲۲۶۷ نفر مرد با سن بین ۷۱ تا ۹۵ سال که مبتلا به پارکینسون نبودن مورد مطالعه ۴ ساله قرار گرفتن، خوب از این افراد در ابتدای ۴ سال تست بویای گرفته شد و حس بویاییشون امتیاز گذاری شد تا این که بعد از ۴ سال یه ۳۵ نفر از این افراد مبتلا به پارکینسون شدند و و همشون تو تست حس بویایی امتیاز پایینی گرفته بودن، نتیجه گییری این بود که با یک ضریب ریسک ۵.۲ افرادی که امتیاز پایین حس بویایی دارند میتونند در ۴ سال آینده مبتلا به پارکینسون بشن
[[Spotlight on olfactory dysfunction in Parkinson’s disease#^baa1cc]]
توی سال ۱۹۹7  هم آقای مارکوپولو کشف کرد که کسانی که به صورت وراثتی دچار پارکینسون میشن دچار اختلال حس بویایی هم هستن 
[[Olfaction in Parkinson's disease and related disorders#^7bf23e]]
 همچنین در تحقیقات دیگری عنوان شده که یک ارتباط ضعیف بین اختلالات شناختی و اختلال حس بویایی وجورد داره که  از بین اختلالات شناختی  اشاره شده که این ارتباط برای حافظه وربال بیشتر وجود داره
[[Olfaction in Parkinson's disease and related disorders#^bfca65]]
، انگیزه برای تحقیقات بیشتر روی این زمینه زیاد تر شد ، و این سوال پیش اومد که اختلال حس بویایی به چه صورت ظاهر میشه و در چند درصد بیماران پارکینسونی وجود داره. خوب تحقیقات مختلف درصد های مختلفی رو عنوان کردن که ماکزیمم تا  ۹۰ درصد رو برای ارتباط اختلال حس بویایی با بیماری پارکینسون گزارش دادن که این میزان از درصد ارتباط با سایر نشانه های حرکتی پارکینسون بیشتر هستش، به طور مثال ارتباط بین پارکینسون ترمور ۷۵ درصد ذکر شده 
[[Olfaction in Parkinson's disease and related disorders#^cd66e1]]

 نوع  این اختلال بویایی رو از مدل
Hyposmia معرفی کردن
( که به معنی کاهش حساسیت دستگاه بویایی هست و نه از مدل Anosmia که به معنی از بین رفتن کامل حس بویایی هست)
[[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease#^6352a6]]


همچنین شناسایی اختلال حس بویایی در افراد میتونه در تمایز بین بیماری پارکینسون با سایر بیماری های مخرب شبکه عصبی مثل بیماری فلج پیشرونده فرا هسته ای یا به انگلیسی 
progressive superunuclear palsy 
کمک کنه چون تحقیقات نشون داده در این بیماری اختلال حس بویایی خیلی کم ظاهر میشه

در ادامه به بحث در مورد علت و منشا ارتباط  اختلال حس بویایی در بیماری پارکینسون میپردازیم






# Reason OF OD in PD and Related  Pathology (10min)
در این بخش میخوایم درباره منشا اختلال بویایی در بیماری پارکنسون صحبت کنیم ، خوب اول با 
 طرح چند سوال شروع میکنیم و در ادامه به جواب این سوالات می پردازیم .فبلش باید بگم که اکثر مق در بسیاری از تحقیقات عنوان شده که هنوز ارتباط دقیق بین اختلال بویایی با سایر بیماری های 
 neurodegenerative
 مثل پارکینسون مشخص نشده
 سوالاتی که در این زمینه مطرحه اینه که 
 1-تا چه حد کمبود در نوروترنسمیتر ها در این پدیده دخیله 
 چندین نوروترنسمیتر در بیماری پارکینسون دچار تغییر میشه که از اونا میشه به دوپامین ،اسیتوکولین و سروتونین اشاره کرد 
  خوب دوپامین مدت زیادیه نقش عمده پاتو ژنی در بیماری پاکینسون داره و در تحقیقات اخیر هم مشخص شده که دوپامین با اختلال بویایی رابطه داره و مطالغات اخیر یک کورلیشینی رو بین و تست های حس بویایی و ترنسپورتر های دوپامین در ناحیه های مختلف مغز نشون دادن این نواحی  سابستنشیا نایگرا ، استرایتم و هیپپوکامپوس بودن
   [[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease#^cdc90f]]
  گزارش شده که اما حس بویایی هیچ پاسخی به دوپامینجریک ریپلیسمنت تراپی نشون نداده که یک روش درمانی برای بیمارانی هست که از سطح پایین دوپامین در بدنشون رنج می برن و خوب این ابهام رو ایجاد کرده ارتباط عملکرد دوپامین با اختلال حس بویایی دقیقا چیه
[[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease#^7ad7aa]]
نورو ترنسمیتر بعدی که در بیماری پارکینسون دچار تغییر میشه اسیتوکلین هست ، سلول های 
 عصبی که از اسیتوکلین برای ارسال پیام استفاده میکنن سلول های عصبی کولینرژیک هستن که به صورت عمده در بخشی از مغز به نام نوکلیس باسالیس میرنت وجود دارند و نشون داده شده که این بخش که با بخش بویایی مغز در ارتباط   در بیماری پارکینسون بهش آسیب وارد میشه و سلول های عصبی کولینرژیک در این بخش تا حدود ۵۰ تا ۷۰ درصد کاهش پیدا میکنند
[[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease#^082a9e]]
خوب ما گفتیم در بیماری پارکینسون به بخش نوکليوس باسالیاس مغز آسیب وارد میشه اما این آسیب ذکر شده که تنها مختص به بیماری پارکینسون نیست و ما در سایر بیماری های مشابه که از نوع نئورو دیجنرتیو یا مخربگر عصبی هستن مثل بیماری آلزایمر هم ما شاهد آسیب به این بخش هستیم و در نتیجه در این بیماری ها هم ما شاهد اختلال حس بویایی هستیم 
[[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease#^082a9e]]
در آزمایش دیگری هم که به طور مشخص ارتباط بین استوکلین و اختلال حس بویایی مشخص شده ، 
 آزمایشی بود که با  از یک روش عکس برداری پزشکی با نام توموگرافی گسیل پزیترون یا پوزیترون امیشن توموگرافی استفاده شده بود که نشون داده شد بین میزان اسییتوکلین و تست حس بویایی یک کورلیشن قوی وجود داره
 [[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease#^a32b08]]
 نوروترنسمیتر بعدی که در اختلال حس بویایی نقش 
ایفا میکنه، سروتونین هست که در بخشی از مغز بنام هسته رافه یا رف نوکلیای واقع در ساقه مغز ساخته 
 میشه، این بخش با بخش مرتبط با حس بویایی مغز به نام 
 اولفکتوری بالب 
 ارتباط عصبی برقرار میکنه.
 در بیماری پارکینسون گزارش شده که اجسام لویی در 
بخش هسته رافه مغز مشاهده شده و با کاهش سروتونین در بخش اولفکتوری بالب مغز مرتبط بودن
[[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease#^e13954]]
خوب این خلاصه تحقیقاتی بود که ارتباط بین تغییر نورو تنسمیتر ها در بیماری پارکینسون با اختلال حس بویایی رو نشون میداد حالا سوال دومی که در این زمینه مطرحه اینه که
۲- آیا  دلایل  پاتولوژی که برای بیماری پارکینسون هست میتونه علت اختلال حس بویایی رو 
 توضیح بده. به طور مثال آیا محله تشکیل لویی بادیس یا همون اجسام لویی که یکی از دلایل ایجاد بیماری پارکینسون هست میتونه با اختلال حس 
 بویایی مرتبط باشه
 که ما در اینجا سعی میکنیم تحقیقات در این زمینه رو تشریح کنیم

- In their important paper, Tsuboi et al. (2003) found that those disorders for which olfactory loss is known to be present, i.e., AD, PD, and LBD, exhibit tau pathology within the bulbar component of the AON, whereas those for which olfactory loss is minimal or generally lacking, i.e., PSP and CBD, such tau pathology is absent. The tau protein plays an important role in stabilizing microtubules and, when hyperphosphorylated, results in the formation of paired helical filaments, known as neurofibrillary treads and tangles. In AD, tau pathology appears before β-amyloid deposition and is found in all segments of the bulb, with the highest level occurring in the AON (Smith et al., 1993). Olfactory deficits are seen in transgenic mice that over express human tau in their olfactory bulbs (Macknin et al., 2004).
[[Olfaction in Parkinson's disease and related disorders]]
 
 گفته شده که از نشانه های اصلی بیماری پارکینسون 
  وجود اجسام لویی در بخشی از مغز بنام سابتنشیا نیگرا هست. آقای براک در تحقیقاتشون  6 مرحله  از درجات مختلف پاتولوژی در بیماری پارکینسون رو شرح دادن که طبق این مراحل اجسام لویی ابتدا در بخش های مختلفی از مغز شروع به شکل گیری میکنن که یکی از این بخشها مرتبط با حس بویایی مغز بنام اولفکتوری بالب هست، 
گزارش شده که بخشی از اجسام لویی که در بیماری پارکینسون نقش ایفا میکنن پروتئینی بنام آلفا سینوکلین هست که در در مراحل اولیه بیماری شروع 
 به جمع شدن در بخش  اولفکتوری بالب مغز میکنن و با عث آسیب به این بخش میشن و بطور مشخص عنوان شده که یکی از بخش هایی که در اولفکتوری بالب آسیب میبینه  بخشی بنام انتریور اولفکتوری نوکلیوس هست که در واقع گیرنده های اولیه برای 
 دریافت بو محسوب میشن
  بنابراین نتیجه گرفته شده که
  توجه به مراحل عنوان شده توسط آقای براک در مورد مکان های پاتولوژی آلفا سینوکلین ها در مغز میتونه توضیح بده که چرا اختلال حس بویایی قبل از اختلالات حرکتی رخ میده و با نتیجه کار آقای راس هم که در موردش در بخش تارخچه این پادکست صحبت کردیم همخونی داره ، نتیجه ایشون  این بود که این نشانه میتونه حداقل ۴ سال زودتر 
  از نشانه های حرکتی رخ بده
[[Spotlight on olfactory dysfunction in Parkinson’s disease#^abbad0]]

 

در ادامه ی این پاکست در باره ی اختصاصیت بین  اختلال حس بویایی و بیماری پاکینسون صحبت میکنیم و اینکه این اختلال تا چقدر میتونه این بیماری رو از سایر بیماری های تخریبگر عصبی یا نئورودیجنریتیو متمایز کنه
 

# OD As Biomarker of PD (10min)
- OD is not PD-specific and is prevalent in aging and other diseases, particularly in neurodegenerative disorders such as Alzheimer’s disease, Huntington’s disease, and rapid-eye-movement sleep-behavior disorder (5–12) #OD_is_not_PD_Specific
خوب شاید تا الان حدس زده باشید که اختلال حس بویایی مختص فقط بیماری پارکینسون نیست و این اختلال با افزایش سن و حتی در سایر بیماری های مخرب شبکه عصبی مثل آلزایمر ، بیماری هانتیگتون، بیماری های مربوط به اختلال خواب غیره وجود داره، بطور مثال 
 از دلایلی که از عدم اختصاصیت اختلال حس بویایی به بیماری پاکینسون عنوان شده اینه که نورترنسمیتر اسیتوکلین که در بخش قبل مورد ارتباطش با اختلال حس بویایی در بیماری پارکینسون  صحبت کرده بودیم در بیماری آلزایمر هم دچار آسیب میشه و این موضوع باعث میشه ما در بیماری آلزایمر هم شاهد اختلال حس بویایی باشیم

بنابراین اختصاصیت اختلال حس بویایی با بیماری پارکینسون پایین هست و سکریین کردن بیماری پارکینسون صرفا با کاهش حس بویایی احتمالا کافی نیست، پس باید این اختلال با نشانه های دیگر بیماری پارکینسون ترکیب بشه که ما در اینجا قصد داریم در مورد این روشهای ترکیبی صحبت کنیم. یکی از راهایی که برای این منظور بیان شده اینه که فاکتور اختلال حس بویایی در یک جمعیت با احتمال ریسک بالا ابتلا به بیماری پارکینسون چک بشه مثل اعضای خانواده درجه یک بیماران پارکینسونی چک بشه  یا
افرادی  یک نوع اختلال خاص خواب بنام 
RAPID EYE MOVEMENT SLEEP DISORDER
پتانسیل تشکیل آلفا-سیکلویین در مغزشون وجود داره و تست حس بویایی در این افراد میتونه سنجش خوبی برای تشخیص ریسک ابتلا به پارکینسون باش


این اختلال مثلا با سایر اختلالات غیر حرکتی ترکیب بشه  بطور مثال در مطالعه آقای راس که در مقدمه این پادکست در موردش صحبت کردیم ایشون فاکتور های غیر حرکتی دیگری مثل یبوست یا  اسلو ریکشن تایم ، خواب آلودگی 
 بیش از اندازه و اختلال حس بویای رو در تحقیقاتشون در نظر گرفتن و افرادی که بین دو یا بیشتر از این فاکتور هارو داشتن به عنوان افرادی با ریسک بالای بیماری پارکیسنون طبقه بندی شدن
 [[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease]]
- While olfactory dysfunction is a disease-sensitive indicator of underlying PD, the specificity is low due to the many other causes of hyposmia in other disorders and the general population. Therefore, screening based on olfactory function alone is unlikely to be adequate. To improve the positive predictive value of olfaction as a screening tool, many studies have used a combination of PD markers, screening in a high-risk population, or a tiered approach to screening in an enriched population to identify those at highest risk for developing PD. For example, when premotor markers (impaired olfaction, constipation, slow reaction time, excessive daytime sleepiness, and impaired executive function) were combined in HAAS, men with 2 or more features had up to a tenfold increased risk for the development of PD [85].[[Olfactory Dysfunction as an Early Biomarker in Parkinson’s Disease]]
در مقالات دیگری بیان شده که اختلال حس بویایی نشانه ای هست که میتونه این بیماری رو از سایر 
 بیماری های مشابه مخرب عصبی متمایز کنه، این بیماری ها 
  بنام 
کورتیک بیسل دیجنریشن و فلج پیشرونده فرا هسته
[[progressive supranuclear palsy]]
ای هستن که تحقیقات نشون داده در این بیماری ها اختلال حس بویایی خیلی کم هست بیماری کورتیک بیسل دیجنریشن باعث کوچک شدن بخش هایی از مغز میشه و سلول های عصبی رو 
 از بین میبره. و بیماری  فلج پیشرونده فرا هسته بیماری هست  که باعث اختلالات حرکتی میشه
 حالا علت اینکه در این بیماری ها آسیب به بخش بویایی کم گزارش شده این بوده که
 خوب ما در بخش قبل که در مورد منشا  اختلال بویایی در پارکینسون صحبت کردیم، گفتیم که آلفا سینوکلین ها وقتی در بخش اولفکتوری بالب مغز تجمع میکنن  موجب آسیب به این بخش میشن  ، تحقیقات نشون داده که علاوه بر آلفا سیکلویین ، پروتيین های دیگر بنام تاو هم  در حسگر های اولیه حس بویایی در مغز وجود دارن و در بیماری پارکینسون نقش بازی میکنن، این در حالیه که در سایر بیماری های مخربگر عصبی یا نورو دیجنریتیو مثل یک بیماری نادری بنام 
کورتیک بیسل دیجنریشن که باعث کوچک شدن بخش هایی از مغز میشه و سلول های عصبی رو 
 از بین میبره. یا بیماری دیگری بنام فلج پیشرونده فرا هسته ای که باعث اختلالات حرکتی میشه ،این پروتين های تاو در حسگر های حس بویایی مشاهده نشدن و عنوان شده که پروتئین های تاو میتونه فقط در بیماری پارکینسون موجب اختلال حس بویایی بشه
  [[Olfaction in Parkinson's disease and related disorders#^0a328b]]

 In addition to alpha-synuclein pathology, tau pathology has also been found in the AON in PD [15, 16]. Interestingly, patients with [[corticobasal degeneration]] (CBD) and [[progressive supranuclear palsy]] (PSP), parkinsonian disorders with little or no olfactory loss, did not demonstrate tau pathology in the AON, suggesting that tau may contribute to olfactory impairment in PD [15, 16]

 [[Olfaction in Parkinson's disease and related disorders#^0a328b]]



  whereas considerably less damage occurs in diseases with little or no olfactory loss, including PSP, amyotrophic lateral sclerosis, and multiple sclerosis [24]. These findings suggest that the association between changes in acetylcholine levels and olfactory impairment may not be specific to PD, and that a common mechanism may underlie olfactory impairment in neurodegenerative diseases.

  Since diagnostic accuracy is lowest early in the disease, this is the time when a marker like olfaction may be useful in distinguishing [[idiopathic]] PD from common differential diagnoses including essential tremor (ET), atypical parkinsonian syndromes, drug-induced parkinsonism, and vascular or other causes of parkinsonism (Table 1). For example, patients with [[tauopathies]] associated with parkinsonism, such as CBD and PSP, tend to have fairly normal olfactory function. 

در متود های دیگری برای تشخیص ارتباط اختلال حس بویایی با بیماری پارکینسون، اومدن تست های حس بویایی رو با روش های عکس برداری ترکیب کردن بطور مثال در تحقیقی ۳۰ بیمار با اختلال حس بویایی انتخاب شدن که از بین این افراد ۱۱ نفرشون افزایش  اکو ژنیسیتی از بخش سابستنسیا نیگرای مغز رو در 
  روش عکس برداری
سوتوگرافی نشون دادن  این در حالی بوده که ۵ نفر از این افراد  در روش عکس برداری بنام دت اسکن که برای سنجش میزان دوپامین استفاده میشه ،عکس های غیر طبیعی داشتن. نتیجه این شده که  ارزیابی حس بویایی و روش عکس بردای سونوگرافی میتونه ریسک  ابتلا به پارکینسون رو تشخبص بده
   Other studies have combined olfactory testing with imaging. Sommer and colleagues identified 30 patients with idiopathic olfactory loss and found that 11 had increased [[echogenicity]] of the [[substantia nigra]] on[[ transcranial sonography]] [86].Five of these patients had abnormal [[DAT imaging]] while two had borderline findings, suggesting olfaction and transcranial sonography together may help identify individuals at a high risk for PD 
روش دیگری که باز با ترکیب حس بویایی برای پیدا کردن افراد مستعد پارکینسون استفاده شده این بوده که تست حس بویایی رو برای  افراد با ریسک بالای  ابتلا به پارکینسون انجام دادن
بطور مثال ه
   A second approach to improving the positive predictive value of olfaction includes using olfactory screening in a population known to be at a high risk for developing PD. Rapid eye movement sleep behavior disorder ([[RBD]]) is a known potential harbinger for the development of an alpha_[[synucleinopathy]], including PD, MSA, and DLB [87, 88]. 

همچینن در روش دیگری گزاریش شده با اندازه گیری های متفاوت دیگری از دستگاه  بویایی مثل بررسی های بافتی بنام روپوشه بویایی یا اولفکتوری اپتلیوم که درون حفره بینی واقع شده یا اندازه حجم بخش اوفکتروی بالب در مغز می تونه یک نشانه مشخص از بیماری پارکینسون یاشه
   Lastly, more recent studies have explored the use of other measures of the olfactory system, such as biopsies of[[ olfactory epithelium]], measurements of olfactory bulb volume, and functional neuroimaging, as potential biomarkers in PD. In one such study, Hummel and colleagues found no pathological changes in the[[ nasal mucosa]] that were specific to PD patients compared to non-PD patients who had other causes of hyposmia, confirming earlier results [122–124]. 
# OD Clinical Assessment (4min)
## how OD measured

# FutureWork (1min)





