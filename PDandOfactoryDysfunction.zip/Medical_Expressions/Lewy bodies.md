Lewy bodies are **clumps of protein that can form in the brain**. When they build up, they can cause problems with the way your brain works, including your memory, movement, thinking skills, mood, and behavior. These problems can keep you from doing everyday tasks or taking care of yourself, a condition called dementia.


 their biochemical composition is α-Synuclein may be the main component of the Lewy body in Parkinson's disease