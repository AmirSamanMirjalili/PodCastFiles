MEDICINE

the cause, set of causes, or manner of causation of a disease or condition.