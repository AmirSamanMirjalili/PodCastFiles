فلج پیشرونده فراهسته ای
Progressive supranuclear palsy (PSP) is a rare brain disorder that causes problems with movement, walking and balance, and eye movement