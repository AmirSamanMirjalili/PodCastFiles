-  Olfactory dysfunction is an early ‘pre-clinical’ sign of Parkinson's disease (PD). The present review is a comprehensive and up-to-date assessment of such dysfunction in PD and related disorders. The olfactory bulb is ==implicated== in the dysfunction, since only those syndromes with olfactory bulb [[pathology]] exhibit significant smell loss.The role of [[dopamine]] in the production of olfactory systempathology is ==enigmatic==, as overexpression of dopaminergic cells within the bulb's glomerular layer is a common feature of PD and most animal models of PD. Damage to cholinergic, serotonergic, and noradrenergic systems is likely involved, s==ince such damage is most marked in those diseases with the most smell loss.== When ==compromised==, these systems, which regulate microglial activity, can influence the induction of localized brain inflammation, oxidative damage, and cytosolic disruption of cellular processes. In monogenetic forms of PD, olfactory dysfunction is rarely observed in asymptomatic gene carriers, but is present in many of those that exhibit the motor phenotype. This suggests that such gene-related influences on olfaction, when present, ==take time to develop and depend upon additional factors==, such as those fromaging, other genes, formation of α-synuclein- and tau-related pathology, or lowered thresholds to oxidative stress from toxic insults. The limited data available suggest that the physiological determinants of the early changes in PD-related olfactory function are likely multifactorial and may include the same determinants as those responsible for a number of other non-motor symptoms of PD, such as dysautonomia and sleep disturbances.




# introduction

- Since its description by James Parkinson in 1817, Parkinson's disease (PD) has been classically viewed as a movement disorder characterized by [[bradykinesia]], [[rigidity]],[[ rest tremor]], and[[ postural instability]] #Motivation_For_OD_In_PD  #How_OD_Associate_In_PD ^7db4bc

- However it is now recognized that PD is one of a spectrum of [[α-synuclein]] and tau-related disorders that are accompanied by such non-motor features as altered smell, taste, vision, [[cardiovascular function]],sleep, gastric and bowel function, salivation, sebaceous gland activity, mood, and [[cognition]] #Source_Of_OD_in_PD 
 
- Among the most salient non-motor features of PD is smell dysfunction, which occurs in at least 90% of cases (Doty et al., 1988a) and often appears years prior to the motor disturbance (Ross et al., 2008).This prevalence is much higher than that of the cardinal sign of [[rest tremor]] (~75%) and rivals or exceeds that of the other cardinal motor signs (Alves et al.,2008) #Motivation_For_OD_In_PD #good_1_1. ^cd66e1

- Had this been known at an earlier time, PD may well have been classified as a primary olfactory disorder with secondary motor accompaniments #Motivation_For_OD_In_PD .


- In addition to the myopic focus on motor disability, two factors are responsible for the historical failure to recognize smell dysfunction as a key feature of PD. First, over 80% of patients with PD have less-than total smell loss and fail to appreciate the dysfunction until tested (Doty et al., 1988a) #Cause_of_OD_Failed_As-Key_Feature_OF_PD.

- This lack of awareness of olfactory loss is also seen in Alzheimer's disease (AD) (Devanandet al., 2000; Doty et al.,1987),in the Parkinson-Dementia Complex of Guam (PDG) (Doty et al., 1991a), and in the general population (Wehling et al., 2011). Second,practical and well-validated quantitative #OD_is_not_PD_Specific

- clinical olfactory tests were not available until the mid-1980s. Following the development of the University of Pennsylvania Smell Identification Test (UPSIT) in 1984 (Fig. 1), nearly a hundred studies have been published in the peer-reviewed literature demonstrating olfactory dysfunction in patients with PD #Motivation_For_OD_In_PD #good1_2  ^a280fc

- This interest was fueled by findings that smell tests can differentiate PD from [[progressive supranuclear palsy]], essential tremor (Busenbark et al., 1992; Shah et al., 2008), and parkinsonism induced by the proneurotoxin 1-methyl-4-phenyl-1,2,5,6 tetrahydropyridine (MPTP) (Doty et al., 1992a) #Motivation_For_OD_In_PD #good1_3 .

-  Interest was further stimulated by a series of landmark neuropathology studies implicating the olfactory bulb as one of two brain regions where PD pathology seems to first appear (Braak et al., 2003a, 2004; Del Tredici et al., 2002) #Source_Of_OD_in_PD.

- Other important milestones that have driven interest in olfaction by neurologists are the pioneering discovery in 1997 of smell loss in some members of families with inherited forms of PD (Markopoulou et al., 1997) and evidence from longitudinal studies that smell testing predicts future development of PD in a sizable number of asymptomatic first degree relatives, as well as in at-risk members of the population at large (Ponsen et al., 2004, 2010; Ross et al., 2008) #Motivation_For_OD_In_PD #good1_3 . ^7bf23e
- The present review is an up-to-date description of the anatomical and functional olfactory abnormalities found in PD and related disorders. The relatively recent discoveries of olfactory dysfunction in genetic forms of PD are reviewed in detail, as are environmental risk factors associated with olfactory loss. As will be shown, multiple factors likely contribute to the development of PD-related olfactory dysfunction. Damage to cholinergic, serotonergic, and noradrenergic systems appear to be as important, if not more important, than damage to the dopaminergic system. Such damage is intertwined with a number of factors, including excessive microglial activation and inflammation, development of α-synuclein- and tau-related neuropathology, and cytosolic disruption of cellular processes such as those involved in monoamine storage and transport.



# Basic anatomy and physiology of the olfactory system
To better understand factors potentially responsible for PD's influence
on olfactory processing, a brief review of basic aspects of olfactory
anatomy and physiology is in order. As will be clear from this section,
there are multiple sectors of the olfactory system where PD-related pathology
can potentially disrupt odor perception 

## Olfactory bulbs
- The olfactory bulbs are a key element of the olfactory system where much of the pathology responsible for PD-related olfactory dysfunction likely resides
- the olfactory bulb has been viewed as the “olfactory thalamus” given that it performs the final stage of sensory processing before information is sent to the cortex (Kay and Sherman, 2007).


# The olfactory phenotype of sporadic Parkinson's disease

- First, the dysfunction is bilateral and robust, being present in 90% or more of [[sporadic PD]] cases (Hawkes and Doty, 2009). Indeed, olfactory tests differentiate PD patients from controls better than clinical motor tests (Bohnen et al., 2008b). #OD_As_Biomarker_OF_PD #good3_1
- In one meta-analysis that compared olfactory test scores of PD patients to those of controls, Cohen effect sizes larger than 3 were found (effect sizes>0.80 are considered (“enormous”) (Mesholam et al., 1998)

- Second, women with PD tend to outperform their male counterparts (Stern et al., 1994), a sex difference seen not only in the general population (Doty et al., 1984a), but in diseases ranging from AD (Doty et al., 1987) to schizophrenia (Good et al., 2007; Seidman et al., 1997) #OD_As_Biomarker_OF_PD 

- Third, [[anosmia]] is not the norm. In one study, only 38% of 81 PD patients had UPSIT scores suggestive of [[anosmia]] and 87% of 38 patients could reliably detect the highest stimulus concentration presented in an odor detection threshold test (Doty et al., 1988a).In another study, all but one of 41 PD patients reported that 35 or more of the 40 UPSIT items had some type of odor, even though the perceived sensation did not correspond to any of the response alternatives (Doty et al., 1992b). #OD_As_Biomarker_OF_PD_Anosmia

- Fourth, the olfactory deficit seems unrelated to specific odorants. Despite the fact that a number of studies have suggested that some odorants differentiate PD from controls better than other odorants, little consistency has been found among studies and the relative influences of culture, odorant intensity, odorant type, and specific response alternatives on the tests are unknown and likely complicate the issue (Boesveldt et al., 2007; Bohnen et al., 2007; Daum et al., 2000; Double et al., 2003; Hawkes et al., 1997; Silveira-Moriyama et al., 2005). #OD_As_Biomarker_OF_PD_odorant_specific

- Fifth, the average olfactory dysfunction of PD is equivalent to that observed in early stage AD and in a number of other neurological diseases. For example, patients with early stage AD, PD, and the Parkinson-Dementia Complex of Guam (PDG) exhibit mean UPSIT scores around 20 (Doty et al., 1991a, 1991b; Mesholam et al., 1998) #OD_is_not_PD_Specific 
- Sixth, olfactory testing can be useful in differential diagnosis, such as discerning PD from[[ progressive supranuclear palsy]] (PSP), #OD_As_Biomarker_OF_PD  #Motivation_For_OD_In_PD #good3_2
- MPTP-induced parkinsonism (MPTP-P), multiple system atrophy (MSA), and essential tremor (ET), disorders with little or no olfactory dysfunction (Busenbark et al., 1992; Doty et al., 1993, 1995a; Ondo and Lai, 2005; Shah et al., 2008; Wenning et al., 1995)
- Seventh, medications used to control the motor dysfunction of PD have no influence on the smell deficit (e.g., L-DOPA, DA agonists anticholinergic compounds). Thus, the smell loss is as severe in nonor never-medicated patients as in medicated ones (Doty et al., 1992b; Quinn et al., 1987; Roth et al., 1998). #PD_Medicine_Not_Cure_OD
- Eighth, the olfactory dysfunction of well-established PD is relatively stable over time and is unrelated to disease stage or duration (Barz et al., 1997; Doty et al., 1988a, 1989, 1992b; Hawkes et al., 1997), #OD_As_Biomarker_OF_PD_is_stabe_over_time
- although this generalization may not apply to all patients or to patients in the earliest stages of the disease (Berendse et al., 2011; Herting et al., 2008; Siderowf et al., 2005; Tissingh et al., 2001). #OD_As_Biomarker_OF_PD_is_stabe_over_time
- Ninth, particularly in later PD stages, suboptimal sniffing behavior may contribute to the olfactory problem. However, the degree of the contribution is small (Sobel et al., 2001).
- Tenth, losses in both olfaction and [[cardiac sympathetic]] function are closely related in PD, as evidenced by strong correlations between olfactory test scores and cardiac 123I-metaiodobenzylguanidine (MIBG) uptake. This association is independent of disease duration and clinical ratings of motor function (Lee et al., 2006). #OD_As_Biomarker_OF_PD 
- Eleventh, although strong relationships between olfactory and cognitive test scores are lacking in PD cohorts (Doty et al., 1989), there is evidence that olfactory test scores are weakly correlated with some cognitive measures in PD, most notably ones involving verbal memory and executive performance (Bohnen et al., 2010; Morley et al., 2011) #OD_As_Biomarker_OF_PD #OD_As_Biomarker_OF_PD_Cognitive #good3_3 ^bfca65
- Twelfth, longitudintal studies demonstrate that the olfactory deficit precedes the classical clinical PD motor signs by several years, serving as a ‘pre-clinical’ or ‘pre-motor’ marker (Haehner et al., 2007; Ponsen et al., 2004; Ross et al., 2005). #OD_As_Biomarker_OF_PD_predicted_several_years_before
- Thirteenth, olfactory testing is sensitive to risk factors associated with future development of PD. Among such risk factors are age (Doty et al., 1984a), head trauma (Doty et al., 1997), and lifetime intake of caffeinated beverages (Siderowf et al., 2007)
- Fourteenth, some asymptomatic first-degree relatives of patients with sporadic forms of PD exhibit olfactory dysfunction that predicts future development of PD (Berendse et al., 2001; Montgomery et al., 1999, 2000; Ponsen et al., 2004). #OD_is_not_PD_Specific_in_Relatives

# [[Etiology]] of PD-related olfactory dysfunction
Despite being well characterized phenotypically, the causes of the olfactory dysfunction of PD and other neurodegenerative diseases are poorly understood #Reason_Of_OD_In_PD. To what extent are deficiencies in specific neurotransmitters involved? Can the location of the classic neuropathology of PD, such as Lewy bodies, explain the olfactory losses? What environmental factors, if any, could induce or catalyze the olfactory dysfunction seen in PD? Can a comparative analysis of the olfactory losses across forms of parkinsonism provide insight into common underlying mechanisms? #Reason_Of_OD_In_PD_Good_Questions These and other questions are addressed in this section of the review. An examination of the neurotransmitter deficits that may contribute to the olfactory dysfunction of PD is provided, followed by types of cells within the olfactory system proper that are likely most vulnerable to PD-related pathology. Since there is an inextricable association between neurotransmitter activity and neuropathology, these two topics are often two sides of the same coin.  ^0a328b


## Neurotransmitter alterations
Among the major neurotransmitters altered in PD and for which considerable olfactory behavioral information is available in other contexts are ACh, DA, 5-HT, and NE. Alterations in any one or combination of these major transmitters and neuromodulators could conceivably produce or contribute to the olfactory dysfunction observed in PD. #Reason_Of_OD_In_PD_Neurotransmitter_alterations


## Acetylcholine
- ACh is widely distributed in the brain and targets not only neurons, but astrocytes and oligodendrocyte progenitors (Carnevale et al., 2007; Cui et al., 2006). Several observations support the hypothesis that cholinergic deficits may be responsible, at least in part, for the olfactory dysfunction of PD. #Reason_Of_OD_In_PD_Neurotransmitter_alterations_Acety
- First, the nucleus basalis – amajor cholinergic nucleus with projections to olfaction-related brain regions – is significantly damaged in PD, with autopsy studies reporting decreases in cell numbers ranging from 54% to 77% (Arendt et al., 1983; Nakano and Hirano, 1984; Rogers et al., 1985
- Finally, an association between ACh and olfactory function in PD was found in a positron emission tomography (PET) study employing the [11C] methyl-4-piperidinyl propionate acetycholinesterase ligand (Bohnen et al., 2010). #Reason_Of_OD_In_PD_Neurotransmitter_alterations

# Dopamine
#Reason_Of_OD_In_PD_Neurotransmitter_alterations_Dop

## PD-related pathology within the olfactory system
- According to Braak and associates, neurons prone to PD-related pathology contain [[α-synuclein]], the sine qua non criterion for defining PD pathology, as well as lipofuscin or neuromelanin granules (Braak and Del, 2009). These authors point out that those non-myelinated or sparsely myelinated projection neurons with disproportionately long and thin axons relative to their soma size are particularly susceptible to the abnormal aggregations and misfoldings of α-synuclein. They make the argument that less myelination places a greater metabolic burden on neurons to accomplish axonal transmission and increases their vulnerability to oxidative stressors associated with neurodegeneration. Additionally, they note that the more myelination, the greater the protection against pathogens and abnormal axonal sprouting. #PD-related_pathology_with_OD
- That being said, generalized α-synuclein pathology within the olfactory receptor cells could conceivably contribute to the PD related smell loss since, with the exception of MSA, smell dysfunction occurs in all of these disorders and in older people generally (Doty et al., 1984a; Hawkes and Doty, 2009).
- Based upon a careful study of pathological material, Braak and his associates have proposed the hypothesis that PD-related pathology advances centrally in a predictable sequence, beginning in the olfactory bulb, the associated [[AON]], and the DMC (Braak et al., 2003a, #PD-related_pathology_with_OD
- 2003b, 2004; Del Tredici et al., 2002) (Fig. 11). Recent work from other laboratories also supports the concept that Lewy pathology may progress along the olfactory pathways, with greater involvement of the bulbs and tracts (Hubbard et al., 2007). Although to a lesser degree than these structures, regions of the olfactory cortex of PD patients at some point display both AD- and PD-related pathology. Thus, Lewy bodies, as well as neurofibrillary tangles, are found within lamina II of the entorhinal cortex (Braak and Braak, 1990). In general, α-synuclein pathology is more severe in the temporal piriform cortex than in its frontal sectors or in the anterior portions of the entorhinal cortex (Silveira-Moriyama et al., 2009a). Interestingly, Lewy bodies have been found in the frontal, temporal, parietal, cingulate, and transentorhinal cortices of LRRK2 PD patients who had olfactory deficits before death (Silveira-Moriyama et al., 2008), a distribution pattern seen in other LRRK2 pathology studies (Ross et al., 2006).
- In their important paper, Tsuboi et al. (2003) found that those disorders for which olfactory loss is known to be present, i.e., AD, PD, and LBD, exhibit tau pathology within the bulbar component of the AON, whereas those for which olfactory loss is minimal or generally lacking, i.e., PSP and CBD, such tau pathology is absent. The tau protein plays an important role in stabilizing microtubules and, when hyperphosphorylated, results in the formation of paired helical filaments, known as neurofibrillary treads and tangles. In AD, tau pathology appears before β-amyloid deposition and is found in all segments of the bulb, with the highest level occurring in the AON (Smith et al., 1993). Olfactory deficits are seen in transgenic mice that over express human tau in their olfactory bulbs (Macknin et al., 2004). #Reason_Of_OD_In_PD_Tau_Pathology
- There is recent evidence that olfactory dysfunction of PD is associated with gray and white matter volumes within the piriformand orbitofrontal cortices (Wattendorf et al., 2009; Wu et al., 2011). Thus, in one
- study early stage PD patients were found to have olfactory test scores that were inversely related to gray matter volume within the right piriform cortex (Wattendorf et al., 2009). In patients with somewhat more advanced PD, a similar correlation was noted between the gray matter volume of the right amygdala and their olfactory testmeasures.Whether such associations are secondary to olfactory bulb damage has yet to be determined, but they do suggest that pathology within higher order olfactory structures may contribute to the olfactory dysfunction observed in PD.

## Associations with xenobiotics

- Most cases of sporadic PD do not have a clearly established genetic basis. Twin studies find little evidence for heritability of PD in those populations that have been evaluated (Tanner et al., 1999; Ward et al., 1983). In the same manner, twin studies suggest that heritability of olfactory function is typically low, particularly in older age groups (Doty et al., 2011).
-







Richard L. Doty ⁎ 2012
![[doty2012 (2) 1.pdf]]